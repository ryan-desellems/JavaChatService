//Name: 	Ryan DeSellemsr
//Course: 	Comp 2230
//Date:		3/25/2021
//Prof:		Larue

import java.io.*;   //simple program to launch client

//==================================================================================
class ClientStarter
{
//==================================================================================
public static void main(String[] args)
{
	//new ChatClient();	//previous GUI format...

	new LoginWindow();  //open login window on start
}
//==================================================================================
}
