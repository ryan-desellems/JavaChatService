//Name: 	Ryan DeSellems
//Course: 	Comp 2230
//Date:		3/25/2021
//Prof:		Larue

import java.io.*;   //simple program to launch server

//==================================================================================
class WindowTester
{
//==================================================================================
public static void main(String[] args)
{
	ChatWindow cw = new ChatWindow();
	cw.openChat("Whatever");
	cw.addToEditor("test");
}
//==================================================================================
}
